print("ejercicio  1")

a=input("ingrese un numero entero: ")
anum = int(a)
print(type(anum))

print("resultado: ")

if anum > 0:
    print("POSITIVO")
elif anum < 0:
    print("NEGATIVO")
elif anum == 0: 
    print("0")
