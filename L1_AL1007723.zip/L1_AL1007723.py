'''variable1 = 21000 #
print("Comentario")
print(variable1)
print(type(variable1)

variable1 = "Hola"
print(variable1)
print(type(variable1)

variable2 = 123.1
print(variable2)
print(type(variable2))

variable3 = False
print(variable3)
print(type(variable3))'''

#print("Hola mundo soy Angie")

'''print("Hola mundo")
print("Soy Angie") 

print("Hola mundo", end="")
print(" soy Angie", end="")'''
#La diferencia entre print y print end es la manera en la que ejecuta la orden ya que en print lo hace dejando cada instruccion en varias lineas y con print end realiza la orden todo en una sola linea definiendo todo como una oracion.

'''texto = input()
print(texto + " Hola")'''

print("Ingrese su nombre: ")
texto = input()
print("Hola mundo")
print("soy " + texto)

print("Ingrese su nombre: ")
texto = input()
print("Hola mundo", end="")
print(" soy " + texto, end="")